import React from 'react';
import styled from 'styled-components';
import LogoPawsindia from './logo_img.png';
import CenterImg from './img1.png'


const LogoImg = styled.img`
width:100px;
margin:20px 0px 0px 20px;
`
const BgImg = styled.img`
width:300px;
align-item:center;
`

const Styledbutton = styled.button`
background-color:pink;
height:60px;
width:250px;
color:darkred;
border-radius:30px;
border:none;
justify-content:center;
font-weight:600;
font-size:24px;
margin-bottom:40px;
`
const Stylediv = styled.div`
align-item:center;
justify-content:center;
text-align:center;
`
const Stylednav = styled.nav`
display:flex;
justify-content:space-between;
align-item:center;
`
const Logo = styled.img`
margin:10px;
`
const Styledli = styled.li`
list-style:none;
font-size:23px;
color:white;
font-weight:500;
padding:10px 20px;
border-radius:30px;

&:hover{
    background-color:lightpink;
    cursor:pointer;
    color:darkred;
}
`
const Styledul = styled.ul`
display:flex;
justify-content:space-between;
align-item:center;
margin-top:25px;
`
const Styleh2 = styled.h2`
align-item:center;
color:red;
font-weight:600;
padding:13px 20px;
`
const Styleh3 = styled.h3`
text-align:center;
font-size:40px;
padding-top:40px;
font-weight:600;
color:skyblue;
`
const Stylebg = styled.div`
background-color:#000000;
margin:0;
box-sizing:box-border;
`
const Styledp = styled.p`
font-size:20px;
text-align:center;
color:lightpink;
padding:20px 100px;
`

const FunctionStyleCompo = () => {
    return (
        <>
        <div>
            <Stylebg>
                <Stylednav>
                    <LogoImg src={LogoPawsindia} alt="Pawsindia"/>
                    {/* <Styleh2>LOGO HERE</Styleh2> */}
                    <Styledul>
                        <Styledli>Home</Styledli>
                        <Styledli>About us</Styledli>
                        <Styledli>Example</Styledli>
                        <Styledli>Contect us</Styledli>
                    </Styledul>
                </Stylednav>
               
                <Styleh3>Start with Excellence</Styleh3>
           {/* <Styledbutton>read more</Styledbutton>  */}
           <Stylediv><BgImg src={CenterImg}/></Stylediv>
           
           <Styledp>What you create is who you are. Slick is designed for the people who have the love for excellence, believe in excellence and love to create impressive things that stand out. Here is more than 172 ready to use elegant UI blocks to start with.</Styledp>
           <Stylediv><Styledbutton>Read More</Styledbutton></Stylediv>
           
            </Stylebg>
            
          
        </div>
        </>
    );
};

export default FunctionStyleCompo;