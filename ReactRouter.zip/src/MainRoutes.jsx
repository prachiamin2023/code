import React from "react";
import { createBrowserRouter } from "react-router-dom";
import Home from "./Home";
import AboutUsPage from "./About";
import Contect from "./Contect";

const MainRoutes = createBrowserRouter([
    {
        // path: "/",
        path: "/",
        element: <Home />,
    },
    {
        path: "/about",
        element: <AboutUsPage />,
    },
     {
        path: "/contect",
        element: <Contect />,
    }, 
    // {
    //     path: "/features",
    //     element: <Features />,
    // }, 
   
]);
export default MainRoutes;