import React from 'react';
import Header from './CommonComponents.jsx/Header';
import { Outlet } from 'react-router-dom';

const About = () => {
    return (
        <div>
            <Header/>
            <h1>About me!</h1>
            <Outlet/>
        </div>
    );
};

export default About;