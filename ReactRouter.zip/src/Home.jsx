import React from 'react';
import Header from './CommonComponents.jsx/Header';
import { Outlet } from 'react-router-dom';

const Home = () => {
    return (
        <>
            <Header/>
            <h2>This is my home page</h2>
            <Outlet/>
        </>
    );
};

export default Home;

