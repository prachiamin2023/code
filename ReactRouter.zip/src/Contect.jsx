import React from 'react';
import Header from './CommonComponents.jsx/Header';
import { Outlet } from 'react-router-dom';

const Contect = () => {
    return (
        <div>
            <Header/>
            <h1>Contect me!</h1>
            <Outlet/>
        </div>
    );
};

export default Contect;