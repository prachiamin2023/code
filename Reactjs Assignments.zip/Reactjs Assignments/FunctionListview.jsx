import React from 'react';
import { Outlet } from 'react-router-dom';

const FunctionListview = () => {
    // const listData = ['Item 1','Item 2','Item 3','Item 4']
    return (
        <>
        <div className='row'>
            <div className='col-6 offset-6'>

            <h3>The "React Way" to Render a List</h3>
            <ul >
                <li>Use Array .map</li>
                <li>Not a For Loop</li>
                <li>Give each item a unique key </li>
                <li>Avoid using array index as the key</li>
            </ul>
            </div>
          
        </div>
          <div className="row">
          <div className="col">
              <Outlet></Outlet>
          </div>
      </div>
      </>
    );
};

export default FunctionListview;