import React, { useState } from 'react';
import './style.css'

const FunctionIncrementDecriment = () => {
 const [count,setCount] = useState(0);

 function increment() {
    setCount(function (prevCount) {
        return (prevCount += 1);
      });
 }
 function decrement() {
    setCount(function (prevCount) {
        return (prevCount -= 1); 
      });
    
 }
 function reset() {
    setCount (function (prevCount) {
        return (prevCount = 0);
    });
    
 }
    return (
        <div className='App text-center'>
        <h1 >{count}</h1>
        <button onClick={increment} className='justify-content-center btnid'>Increment</button>
        <button onClick={reset} className='justify-content-center btnid'>Reset</button>
        <button  onClick={decrement} className='justify-content-center btnid'>Decrement</button>
      </div>
    );
};

export default FunctionIncrementDecriment;